# Sistema de GENET — despliegue en Render

Este es el mismo sistema (Node.js + Express + PostgreSQL), listo para desplegar
en Render en vez de Railway. El código es idéntico — solo cambian los pasos
de configuración de la plataforma.

## Archivos que tenés que subir a tu repositorio de GitHub

```
server.js
db.js
package.json
.gitignore
public/index.html
```

(Los mismos de siempre. Si ya tenías un repo de Railway, podés reutilizarlo —
reemplazá el contenido de `server.js` y `db.js` por los de esta versión, ya
que tienen un ajuste para funcionar mejor en Render.)

## Paso a paso en Render

### 1. Creá la base de datos primero
- En el Dashboard de Render → **New +** → **PostgreSQL**.
- Ponele un nombre (ej: `genet-db`), elegí la región más cercana, plan **Free** para arrancar.
- Click en **Create Database**. Esperá a que quede en estado "Available" (un par de minutos).

⚠️ **Importante sobre el plan gratuito de Render:** las bases de datos Postgres gratuitas de Render **se eliminan automáticamente a los 30 días** si no las pasás a un plan pago. Para probar el sistema está perfecto, pero si vas a usarlo en serio con tu negocio, vas a necesitar pasar la base de datos a un plan pago antes de que se cumplan los 30 días (o vas a perder todo el catálogo cargado).

### 2. Copiá la URL interna de conexión
- Ya dentro de tu base de datos creada, buscá la sección **Connections**.
- Copiá el valor de **Internal Database URL** (no el "External" — el interno es más rápido y no cuenta contra límites de datos, porque la conexión queda dentro de la misma red de Render).

### 3. Creá el servicio web
- Dashboard → **New +** → **Web Service**.
- Conectá tu repositorio de GitHub (el que tiene `server.js`, `db.js`, etc.).
- Configuración:
  - **Name**: el nombre que quieras (ej: `sistema-genet`)
  - **Region**: la misma que elegiste para la base de datos, así se conectan más rápido
  - **Build Command**: `npm install`
  - **Start Command**: `npm start`
  - **Plan**: Free para arrancar (con la aclaración de que los planes gratuitos de Render "duermen" el servicio tras un rato sin uso, y tarda unos segundos en volver a responder la primera vez que alguien entra después de estar inactivo)

### 4. Agregá las variables de entorno
Antes de crear el servicio (o después, en la pestaña **Environment**), agregá:

| Variable | Valor |
|---|---|
| `DATABASE_URL` | pegá acá la Internal Database URL que copiaste en el paso 2 |
| `ADMIN_USER` | el usuario para entrar al panel (ej: `admin`) |
| `ADMIN_PASSWORD` | una contraseña segura tuya |
| `JWT_SECRET` | cualquier texto largo y random |

`PORT` no hace falta configurarlo — Render lo asigna solo y el código ya lo usa.

### 5. Desplegá
- Click en **Create Web Service**. Render va a instalar las dependencias y arrancar el servidor automáticamente.
- Mirá los logs de despliegue (pestaña **Logs**) — deberías ver algo como:
  ```
  Usuario administrador creado: "admin". Cambiá la contraseña por defecto en producción.
  Sistema de GENET corriendo en el puerto XXXX
  ```

### 6. Encontrá tu URL pública
- Arriba de la página de tu servicio, Render muestra la URL directamente (algo como `https://sistema-genet.onrender.com`).
- Abrila en el navegador — ahí tenés tu Punto de Venta.

### 7. Primer ingreso
- Pestaña **Administración** → usuario y contraseña que pusiste en el paso 4.
- Cargá tus productos — aparecen al instante en el Punto de Venta.

## Actualizaciones futuras

Cada vez que subas cambios a la rama principal de tu repositorio de GitHub,
Render redespliega automáticamente (esto se puede desactivar en Settings si
alguna vez preferís desplegar manualmente).

## Diferencias importantes respecto a Railway

- **Free tier "duerme"**: en el plan gratuito, si nadie usa el sistema por un rato, Render "duerme" el servicio. La primera visita después de eso tarda unos 30-50 segundos en responder mientras se despierta. Para uso real de un comercio, conviene pasar a un plan pago (arrancan baratos) para que esté siempre disponible al instante.
- **Base de datos gratuita expira a los 30 días** (ver aviso más arriba) — no pasa lo mismo en Railway.
- El resto (variables de entorno, cómo se conecta la app a la base, cómo funciona el sistema) es equivalente.

## Notas de seguridad

- Cambiá `ADMIN_PASSWORD` por una contraseña fuerte antes de usar el sistema con datos reales.
- No compartas la URL del servicio ni las variables de entorno públicamente.
